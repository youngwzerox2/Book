import { Card, Grid, Typography } from '@mui/material';

const { Container, Box } = require('@mui/system');

const IntroduceContent = () => {
  return (
    <Grid>
      <Container>
        <Card>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              py: 4.5,
              height: '200px',
              backgroundColor: 'grey.200',
              margin: '20px'
            }}
          >
            <Typography>넷플릭스를 훔쳐온 시작페이지 구성</Typography>
          </Box>
        </Card>
      </Container>
      <Container>
        <Card>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              py: 4.5,
              height: '200px',
              backgroundColor: 'grey.200',
              margin: '20px'
            }}
          >
            <Typography>설명문구를 정하지 못했다</Typography>
          </Box>
        </Card>
      </Container>
      <Container>
        <Card>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              py: 4.5,
              height: '200px',
              backgroundColor: 'grey.200',
              margin: '20px'
            }}
          >
            <Typography>나중에 잘 넣어보겠습니다</Typography>
          </Box>
        </Card>
      </Container>
    </Grid>
  );
};

export default IntroduceContent;
