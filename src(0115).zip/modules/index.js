import { combineReducers } from 'redux';
import paging from './cpaging';

const reducer = combineReducers({
  paging
});

export default reducer;
