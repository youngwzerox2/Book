import PropTypes from 'prop-types';

// material-ui
import { Box } from '@mui/material';

// project import
import MainCard from 'ui-component/cards/MainCard';

// ==============================|| AUTHENTICATION CARD WRAPPER ||============================== //

const BasicFrame = ({ children, ...other }) => (
  <MainCard
    sx={{
      // 원래 lg 475임
      maxWidth: { xs: 400, lg: 725 },
      margin: { xs: 2.5, md: 3 },
      '& > *': {
        flexGrow: 1,
        flexBasis: '50%'
      }
    }}
    content={false}
    {...other}
  >
    <Box sx={{ p: { xs: 2, sm: 3, xl: 5 } }}>{children}</Box>
  </MainCard>
);

BasicFrame.propTypes = {
  children: PropTypes.node
};

export default BasicFrame;
